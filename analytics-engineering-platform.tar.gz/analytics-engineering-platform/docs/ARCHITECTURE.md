# Arquitetura da Plataforma de Analytics Engineering

## Visão Geral

Esta plataforma implementa uma arquitetura moderna de dados (Modern Data Stack) para analytics engineering, seguindo as melhores práticas da indústria.

## Componentes Principais

### 1. Camada de Dados (Data Layer)

```
┌─────────────────────────────────────────────────────┐
│                  PostgreSQL                         │
│  ┌──────────┬──────────────┬──────────────────┐   │
│  │  public  │   staging    │   intermediate   │   │
│  │ (raw)    │   (bronze)   │     (silver)     │   │
│  └──────────┴──────────────┴──────────────────┘   │
│  ┌──────────┬──────────────┬──────────────────┐   │
│  │  marts   │    seeds     │   snapshots      │   │
│  │ (gold)   │              │                  │   │
│  └──────────┴──────────────┴──────────────────┘   │
└─────────────────────────────────────────────────────┘
```

#### Schemas:

- **public**: Dados brutos (raw tables)
- **staging**: Primeira camada de transformação (bronze)
- **intermediate**: Transformações intermediárias (silver)
- **marts**: Dados prontos para consumo (gold)
- **seeds**: Dados de referência estáticos
- **snapshots**: Histórico de dados (SCD Type 2)

### 2. Camada de Transformação (Transformation Layer)

**dbt (Data Build Tool)**

```
models/
├── staging/           # Bronze Layer
│   ├── stg_orders.sql
│   ├── stg_customers.sql
│   └── stg_products.sql
│
├── intermediate/      # Silver Layer
│   └── int_orders_enriched.sql
│
└── marts/            # Gold Layer
    ├── fct_orders.sql
    ├── dim_customers.sql
    ├── dim_products.sql
    └── agg_daily_sales.sql
```

**Responsabilidades:**
- Limpeza e padronização de dados
- Aplicação de regras de negócio
- Criação de métricas e KPIs
- Modelagem dimensional
- Testes de qualidade de dados

### 3. Camada de Orquestração (Orchestration Layer)

**Apache Airflow**

```python
DAG: analytics_pipeline
├── check_database_connection
├── dbt_deps
├── dbt_seed
├── dbt_run_staging → dbt_test_staging
├── dbt_run_intermediate
├── dbt_run_marts → dbt_test_marts
├── data_quality_validation
├── dbt_docs_generate
└── send_success_notification
```

**Funcionalidades:**
- Agendamento de pipelines
- Gestão de dependências
- Retry e error handling
- Monitoramento e alertas
- Logging centralizado

### 4. Camada de Qualidade (Data Quality Layer)

**Great Expectations**

- Validações de schema
- Testes de integridade referencial
- Verificações de valores aceitos
- Detecção de anomalias
- Documentação de expectativas

## Padrões de Design

### Medalion Architecture (Bronze, Silver, Gold)

#### Bronze (Staging)
- **Objetivo**: Dados brutos limpos
- **Transformações**: Mínimas (rename, cast, trim)
- **Materialização**: Views
- **Exemplo**: `stg_orders`, `stg_customers`

#### Silver (Intermediate)
- **Objetivo**: Enriquecimento e joins
- **Transformações**: Cálculos, agregações, joins
- **Materialização**: Views ou Tables incrementais
- **Exemplo**: `int_orders_enriched`

#### Gold (Marts)
- **Objetivo**: Dados prontos para BI
- **Transformações**: Modelagem dimensional
- **Materialização**: Tables
- **Exemplo**: `fct_orders`, `dim_customers`, `agg_daily_sales`

### Modelagem Dimensional

#### Star Schema

```
        ┌──────────────┐
        │dim_customers │
        └──────┬───────┘
               │
        ┌──────▼───────┐
        │  fct_orders  │
        └──────┬───────┘
               │
        ┌──────▼───────┐
        │ dim_products │
        └──────────────┘
```

**Fact Tables (Fatos):**
- `fct_orders`: Transações de pedidos
  - Granularidade: Um registro por pedido
  - Métricas: amounts, quantities
  - Foreign keys: customer_id, product_id

**Dimension Tables (Dimensões):**
- `dim_customers`: Atributos de clientes
- `dim_products`: Catálogo de produtos
- `dim_date` (futuro): Calendário

### Convenções de Nomenclatura

```
Staging:     stg_{source}_{entity}
Intermediate: int_{entity}_{description}
Facts:       fct_{entity}
Dimensions:  dim_{entity}
Aggregates:  agg_{granularity}_{entity}
```

## Fluxo de Dados

### 1. Ingestão (Extract)

```
Source Systems → PostgreSQL (public schema)
```

Dados são carregados nas tabelas raw:
- `raw_orders`
- `raw_customers`
- `raw_products`

### 2. Transformação (Transform)

```
dbt run → staging → intermediate → marts
```

**Staging Layer:**
```sql
-- Exemplo: stg_orders.sql
SELECT
    order_id,
    CAST(amount AS DECIMAL(10,2)) AS order_amount,
    LOWER(TRIM(status)) AS order_status
FROM {{ source('ecommerce', 'raw_orders') }}
```

**Intermediate Layer:**
```sql
-- Exemplo: int_orders_enriched.sql
SELECT
    o.*,
    c.full_name AS customer_name,
    EXTRACT(YEAR FROM o.order_date) AS order_year
FROM {{ ref('stg_orders') }} o
LEFT JOIN {{ ref('stg_customers') }} c 
    ON o.customer_id = c.customer_id
```

**Marts Layer:**
```sql
-- Exemplo: fct_orders.sql
SELECT
    order_id,
    customer_id,
    order_date,
    total_amount,
    CURRENT_TIMESTAMP AS dbt_updated_at
FROM {{ ref('int_orders_enriched') }}
```

### 3. Validação (Test)

```
dbt test → Executa testes de qualidade
```

**Tipos de testes:**
- **Uniqueness**: Primary keys únicas
- **Not Null**: Campos obrigatórios
- **Relationships**: Foreign keys válidas
- **Accepted Values**: Valores em lista permitida
- **Custom Tests**: Regras de negócio específicas

### 4. Documentação (Document)

```
dbt docs generate → Gera documentação interativa
```

Documentação inclui:
- Lineage (linhagem de dados)
- Schema de tabelas
- Descrições de campos
- Testes aplicados
- Métricas de execução

## Estratégias de Materialização

### Views
```yaml
models:
  staging:
    +materialized: view
```
- **Vantagens**: Sempre atualizadas, sem storage extra
- **Desvantagens**: Queries mais lentas
- **Uso**: Staging e intermediate

### Tables
```yaml
models:
  marts:
    +materialized: table
```
- **Vantagens**: Queries rápidas
- **Desvantagens**: Requer rebuild completo
- **Uso**: Marts, agregações

### Incremental
```yaml
models:
  some_model:
    +materialized: incremental
    +unique_key: id
```
- **Vantagens**: Atualiza apenas novos registros
- **Desvantagens**: Mais complexo
- **Uso**: Tabelas grandes com particionamento

## Monitoramento e Observabilidade

### Métricas Chave

1. **Pipeline Health**
   - Success rate
   - Execution time
   - Failure alerts

2. **Data Quality**
   - Test pass rate
   - Schema changes
   - Row counts

3. **Performance**
   - Query execution time
   - Resource usage
   - Bottlenecks

### Logs

Logs são centralizados no Airflow:
- Task execution logs
- dbt run logs
- Error traces
- Performance metrics

## Escalabilidade

### Estratégias de Otimização

1. **Particionamento**
   - Por data
   - Por região
   - Por categoria

2. **Indexes**
   - Primary keys
   - Foreign keys
   - Campos de filtro frequentes

3. **Incremental Loads**
   - Apenas novos/modificados
   - Window functions
   - Merge strategies

4. **Parallel Execution**
   - Airflow: Multiple workers
   - dbt: Threads configuration

## Segurança

### Controle de Acesso

```
Roles:
├── analytics_engineer (read/write em dbt schemas)
├── data_analyst (read-only em marts)
└── data_scientist (read-only em todos schemas)
```

### Boas Práticas

- Credentials em variáveis de ambiente
- Secrets management (Airflow Connections)
- Audit logs
- Data masking para PII

## Disaster Recovery

### Backup Strategy

1. **Database Backups**
   - Daily full backups
   - Point-in-time recovery

2. **Code Versioning**
   - Git para todo código
   - Semantic versioning
   - Tags de release

3. **Documentation**
   - dbt docs versionado
   - Runbooks atualizados

## Próximos Passos

### Melhorias Futuras

1. **CI/CD**
   - GitHub Actions
   - Automated testing
   - Deployment pipeline

2. **Data Catalog**
   - Atlan ou similar
   - Metadata management

3. **Advanced Analytics**
   - ML models
   - Predictive analytics
   - Real-time streaming

4. **Multi-environment**
   - Dev, Staging, Prod
   - Environment-specific configs

## Referências

- [dbt Best Practices](https://docs.getdbt.com/guides/best-practices)
- [Airflow Documentation](https://airflow.apache.org/docs/)
- [Kimball Dimensional Modeling](https://www.kimballgroup.com/)
- [Analytics Engineering Guide](https://www.getdbt.com/analytics-engineering/)
